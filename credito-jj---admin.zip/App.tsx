
import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Navbar from './components/Navbar';
import Dashboard from './components/Dashboard';
import ClientModule from './components/ClientModule';
import LoanModule from './components/LoanModule';
import CollectionModule from './components/CollectionModule';
import AccountingModule from './components/AccountingModule';
import RouteModule from './components/RouteModule';
import SettingsModule from './components/SettingsModule';
import BottomNav from './components/BottomNav';
import { User, UserRole } from './types';
import { supabase } from './lib/supabase';

const App: React.FC = () => {
  const [session, setSession] = useState<any>(null);
  const [activeTab, setActiveTab] = useState('dashboard');
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);
  const [loading, setLoading] = useState(true);
  
  // Auth states
  const [isRegistering, setIsRegistering] = useState(false);
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [fullName, setFullName] = useState('');
  const [error, setError] = useState('');
  const [authLoading, setAuthLoading] = useState(false);

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      setLoading(false);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session) setError('');
    });

    return () => subscription.unsubscribe();
  }, []);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    if (password.length < 6) {
      setError('La contraseña debe tener al menos 6 caracteres.');
      return;
    }
    setAuthLoading(true);

    try {
      if (isRegistering) {
        const { data, error: signUpError } = await supabase.auth.signUp({
          email,
          password,
          options: { data: { full_name: fullName, role: UserRole.ADMIN } }
        });
        if (signUpError) {
          setError(signUpError.message);
        } else if (data.user && !data.session) {
          setError('¡Cuenta creada! Revisa tu correo para confirmar.');
        }
      } else {
        const { error: signInError } = await supabase.auth.signInWithPassword({ email, password });
        if (signInError) setError('Correo o contraseña incorrectos.');
      }
    } catch (err: any) {
      setError('Error de conexión.');
    } finally {
      setAuthLoading(false);
    }
  };

  const handleLogout = async () => {
    await supabase.auth.signOut();
  };

  if (loading) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-50">
        <div className="flex flex-col items-center">
          <div className="w-12 h-12 border-4 border-indigo-600 border-t-transparent rounded-full animate-spin mb-4"></div>
          <p className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Iniciando CREDITO JJ...</p>
        </div>
      </div>
    );
  }

  if (!session) {
    return (
      <div className="min-h-screen flex items-center justify-center bg-slate-100 p-4">
        <div className="bg-white p-8 sm:p-12 rounded-[3.5rem] shadow-2xl w-full max-w-md border border-slate-100 animate-in fade-in slide-in-from-bottom-4 duration-500">
          <div className="text-center mb-10">
            <div className="w-20 h-20 bg-indigo-600 rounded-[2rem] flex items-center justify-center mx-auto mb-6 shadow-2xl shadow-indigo-200 -rotate-3">
               <span className="text-white text-3xl font-black">JJ</span>
            </div>
            <h1 className="text-3xl font-black text-slate-900 tracking-tight">CREDITO JJ</h1>
            <p className="text-slate-400 text-[10px] font-bold uppercase tracking-[0.2em] mt-3">Sistema de Gestión de Préstamos</p>
          </div>
          
          <form onSubmit={handleAuth} className="space-y-4">
            {error && <div className="p-4 rounded-2xl bg-rose-50 border border-rose-100 text-rose-600 text-[11px] font-bold text-center">{error}</div>}
            {isRegistering && (
              <div className="space-y-1">
                <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nombre Completo</label>
                <input type="text" value={fullName} onChange={(e) => setFullName(e.target.value)} className="w-full px-6 py-4.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold text-sm" required />
              </div>
            )}
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Correo</label>
              <input type="email" value={email} onChange={(e) => setEmail(e.target.value)} className="w-full px-6 py-4.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold text-sm" required />
            </div>
            <div className="space-y-1">
              <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Contraseña</label>
              <input type="password" value={password} onChange={(e) => setPassword(e.target.value)} className="w-full px-6 py-4.5 bg-slate-50 border border-slate-200 rounded-2xl focus:ring-4 focus:ring-indigo-500/10 outline-none font-bold text-sm" required />
            </div>
            <button type="submit" disabled={authLoading} className="w-full bg-indigo-600 hover:bg-indigo-700 text-white font-black text-xs uppercase tracking-widest py-5 rounded-2xl transition-all shadow-xl shadow-indigo-100 mt-6 disabled:opacity-50">
              {authLoading ? 'Cargando...' : (isRegistering ? 'Registrarme' : 'Entrar')}
            </button>
          </form>
          <button onClick={() => setIsRegistering(!isRegistering)} className="w-full mt-8 text-[10px] font-black text-indigo-600 uppercase tracking-widest">{isRegistering ? 'Ya tengo cuenta' : 'Crear cuenta nueva'}</button>
        </div>
      </div>
    );
  }

  const user: User = {
    id: session.user.id,
    username: session.user.email?.split('@')[0] || 'usuario',
    name: session.user.user_metadata?.full_name || session.user.email,
    role: (session.user.user_metadata?.role as UserRole) || UserRole.ADMIN
  };

  const renderContent = () => {
    switch (activeTab) {
      case 'dashboard': return <Dashboard />;
      case 'clients': return <ClientModule />;
      case 'loans': return <LoanModule />;
      case 'collections': return <CollectionModule user={user} />;
      case 'cashflow': return <AccountingModule />;
      case 'routes': return <RouteModule />;
      case 'settings': return <SettingsModule />;
      default: return <Dashboard />;
    }
  };

  return (
    <div className="flex min-h-screen bg-slate-50 text-slate-900">
      <div className="hidden lg:block">
        <Sidebar user={user} activeTab={activeTab} setActiveTab={setActiveTab} isOpen={isSidebarOpen} setIsOpen={setIsSidebarOpen} />
      </div>
      <div className={`flex-1 flex flex-col transition-all duration-300 ${isSidebarOpen ? 'lg:ml-64' : 'lg:ml-20'} pb-24 lg:pb-0`}>
        <Navbar user={user} onLogout={handleLogout} />
        <main className="p-4 sm:p-6 lg:p-10 flex-1 overflow-y-auto">{renderContent()}</main>
      </div>
      <BottomNav user={user} activeTab={activeTab} setActiveTab={setActiveTab} />
    </div>
  );
};

export default App;
