
import React from 'react';
import { Globe, Shield, Smartphone, Zap, CheckCircle, ExternalLink, Database } from 'lucide-react';

const SettingsModule: React.FC = () => {
  return (
    <div className="max-w-4xl mx-auto space-y-8 pb-20 animate-in fade-in duration-500">
      <div>
        <h1 className="text-3xl font-black text-slate-900 tracking-tight">Configuración</h1>
        <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Gestión de CREDITO JJ en producción</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Guía de Despliegue Propio */}
        <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm space-y-6">
          <div className="w-14 h-14 bg-indigo-600 rounded-2xl flex items-center justify-center text-white shadow-lg shadow-indigo-100">
            <Globe size={28} />
          </div>
          <div>
            <h3 className="text-lg font-black text-slate-900">Dominio Propio</h3>
            <p className="text-sm text-slate-500 mt-2 font-medium">Lleva CREDITO JJ a tu propia dirección web para compartirla con tus cobradores sin pasar por AI Studio.</p>
          </div>
          
          <div className="space-y-4">
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-[10px] font-black shrink-0">1</div>
              <p className="text-xs text-slate-600 font-bold">Crea una cuenta en <span className="text-indigo-600">Vercel.com</span></p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-[10px] font-black shrink-0">2</div>
              <p className="text-xs text-slate-600 font-bold">Conecta tu cuenta de GitHub con los archivos de la App.</p>
            </div>
            <div className="flex items-start gap-3">
              <div className="w-6 h-6 rounded-full bg-indigo-100 flex items-center justify-center text-indigo-600 text-[10px] font-black shrink-0">3</div>
              <p className="text-xs text-slate-600 font-bold">Asigna tu dominio (Ej: cobranza-jj.com) en el panel de Vercel.</p>
            </div>
          </div>

          <a 
            href="https://vercel.com/docs/deployments/overview" 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex items-center justify-center w-full py-4 bg-slate-900 text-white rounded-2xl text-[10px] font-black uppercase tracking-widest hover:bg-slate-800 transition-colors"
          >
            Ver Guía Oficial <ExternalLink size={14} className="ml-2" />
          </a>
        </div>

        {/* Seguridad Supabase */}
        <div className="bg-indigo-900 p-8 rounded-[2.5rem] text-white shadow-xl space-y-6 relative overflow-hidden">
          <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center text-indigo-200 border border-white/10 backdrop-blur-md">
            <Shield size={28} />
          </div>
          <div className="relative z-10">
            <h3 className="text-lg font-black">Seguridad de Datos</h3>
            <p className="text-sm text-indigo-200 mt-2 font-medium">Tu base de datos en Supabase está protegida. Los cobradores solo pueden ver lo que tú les permitas.</p>
          </div>

          <div className="space-y-4 relative z-10">
            <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/5">
              <CheckCircle size={18} className="text-emerald-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Copia de seguridad Diaria</span>
            </div>
            <div className="flex items-center gap-3 p-4 bg-white/5 rounded-2xl border border-white/5">
              <CheckCircle size={18} className="text-emerald-400" />
              <span className="text-[10px] font-bold uppercase tracking-wider">Borrado en Cascada Activo</span>
            </div>
          </div>

          <div className="absolute -bottom-10 -right-10 w-40 h-40 bg-indigo-500 rounded-full blur-3xl opacity-20"></div>
        </div>
      </div>

      {/* Ajustes de App */}
      <div className="bg-white p-8 rounded-[2.5rem] border border-slate-100 shadow-sm">
        <h3 className="text-sm font-black text-slate-400 uppercase tracking-[0.2em] mb-8">Personalización de la Marca</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Nombre de la App</label>
            <input 
              type="text" 
              className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none"
              defaultValue="CREDITO JJ"
            />
          </div>
          <div className="space-y-2">
            <label className="text-[10px] font-black text-slate-400 uppercase tracking-widest ml-1">Tasa de Interés (%)</label>
            <div className="relative">
              <input 
                type="number" 
                className="w-full p-4 bg-slate-50 border border-slate-200 rounded-2xl text-sm font-bold focus:ring-4 focus:ring-indigo-500/10 outline-none"
                defaultValue="20"
              />
              <span className="absolute right-4 top-1/2 -translate-y-1/2 font-black text-indigo-600">%</span>
            </div>
          </div>
        </div>
        
        <div className="mt-8 pt-8 border-t border-slate-100 flex justify-end">
          <button className="bg-indigo-600 text-white px-8 py-4 rounded-2xl font-black text-xs uppercase tracking-widest shadow-xl shadow-indigo-100 hover:bg-indigo-700 active:scale-95 transition-all">
            Guardar Cambios
          </button>
        </div>
      </div>
    </div>
  );
};

export default SettingsModule;
