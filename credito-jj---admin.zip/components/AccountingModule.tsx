
import React, { useState, useEffect } from 'react';
import { Wallet, ArrowDownCircle, ArrowUpCircle, Printer, Share2, Calculator, CheckCircle2, Loader2 } from 'lucide-react';
import { supabase } from '../lib/supabase';

const AccountingModule: React.FC = () => {
  const [data, setData] = useState({
    ingresos: 0,
    egresos: 0,
    transactions: [] as any[]
  });
  const [loading, setLoading] = useState(true);

  const fetchAccounting = async () => {
    setLoading(true);
    const today = new Date().toISOString().split('T')[0];
    
    const { data: trans, error } = await supabase
      .from('cash_transactions')
      .select('*')
      .gte('created_at', today)
      .order('created_at', { ascending: false });

    if (!error && trans) {
      const ingresos = trans.filter(t => t.type === 'INGRESO').reduce((acc, t) => acc + t.amount, 0);
      const egresos = trans.filter(t => t.type === 'EGRESO').reduce((acc, t) => acc + t.amount, 0);
      setData({ ingresos, egresos, transactions: trans });
    }
    setLoading(false);
  };

  useEffect(() => {
    fetchAccounting();
  }, []);

  if (loading) return <div className="flex justify-center py-20"><Loader2 className="animate-spin text-indigo-600" /></div>;

  return (
    <div className="space-y-6 animate-in fade-in duration-500">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-black text-slate-900 tracking-tight uppercase">Cuadre de Caja</h1>
          <p className="text-xs font-bold text-slate-400 uppercase tracking-widest mt-1">Fecha: {new Date().toLocaleDateString()}</p>
        </div>
        <button onClick={fetchAccounting} className="p-2.5 bg-white border border-slate-200 text-indigo-600 rounded-xl shadow-sm active:scale-95 transition-transform">
           <Calculator size={20} />
        </button>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-white p-6 rounded-[2rem] border border-slate-100 shadow-sm md:col-span-2">
          <div className="grid grid-cols-2 gap-4 mb-8">
            <div className="p-4 bg-emerald-50 rounded-2xl border border-emerald-100">
              <div className="flex items-center text-emerald-600 mb-1">
                <ArrowDownCircle size={14} className="mr-1" />
                <span className="text-[10px] font-black uppercase tracking-widest">Ingresos</span>
              </div>
              <p className="text-2xl font-black text-emerald-700">${data.ingresos.toLocaleString()}</p>
            </div>
            <div className="p-4 bg-rose-50 rounded-2xl border border-rose-100">
              <div className="flex items-center text-rose-600 mb-1">
                <ArrowUpCircle size={14} className="mr-1" />
                <span className="text-[10px] font-black uppercase tracking-widest">Egresos</span>
              </div>
              <p className="text-2xl font-black text-rose-700">${data.egresos.toLocaleString()}</p>
            </div>
          </div>

          <div className="space-y-4">
            <h4 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.2em]">Historial de Hoy</h4>
            <div className="divide-y divide-slate-100">
              {data.transactions.length > 0 ? data.transactions.map((t, i) => (
                <div key={i} className="py-4 flex justify-between items-center group">
                  <div>
                    <span className="text-sm font-bold text-slate-700 block group-hover:text-indigo-600 transition-colors">{t.description}</span>
                    <span className="text-[9px] text-slate-400 uppercase font-black tracking-widest">{t.category}</span>
                  </div>
                  <span className={`text-sm font-black ${t.type === 'INGRESO' ? 'text-emerald-600' : 'text-rose-600'}`}>
                    {t.type === 'INGRESO' ? '+' : '-'}${t.amount.toLocaleString()}
                  </span>
                </div>
              )) : (
                <div className="py-12 text-center">
                  <p className="text-slate-300 font-bold uppercase text-[10px] tracking-widest">No hay movimientos registrados hoy</p>
                </div>
              )}
            </div>
          </div>

          <div className="pt-6 border-t border-slate-200 mt-6">
            <div className="flex items-center justify-between p-6 bg-slate-900 rounded-[2rem] text-white shadow-xl shadow-slate-200">
              <div>
                <p className="text-[10px] text-slate-400 font-black uppercase tracking-[0.2em] mb-1">Balance Neto</p>
                <p className="text-3xl font-black tracking-tighter">${(data.ingresos - data.egresos).toLocaleString()}</p>
              </div>
              <div className="w-14 h-14 bg-white/10 rounded-2xl flex items-center justify-center">
                <Wallet size={28} className="text-indigo-400" />
              </div>
            </div>
          </div>
        </div>

        <div className="space-y-6">
          <div className="bg-indigo-600 p-8 rounded-[2.5rem] text-white shadow-xl shadow-indigo-100 flex flex-col items-center text-center">
            <div className="w-16 h-16 bg-white/20 rounded-3xl flex items-center justify-center mb-6 backdrop-blur-sm">
              <Share2 size={32} />
            </div>
            <h4 className="font-black text-lg mb-2 uppercase tracking-tight">Enviar Reporte</h4>
            <p className="text-xs text-indigo-100 mb-6 leading-relaxed font-medium">
              Comparte el balance del día de <strong>CREDITO JJ</strong> con el supervisor.
            </p>
            <button 
              onClick={() => {
                const msg = `*CIERRE DE CAJA CREDITO JJ - ${new Date().toLocaleDateString()}*\n\n💰 Ingresos: $${data.ingresos}\n💸 Egresos: $${data.egresos}\n⚖️ Balance Neto: $${data.ingresos - data.egresos}`;
                window.open(`https://wa.me/?text=${encodeURIComponent(msg)}`, '_blank');
              }}
              className="w-full py-4 bg-white text-indigo-700 rounded-2xl text-xs font-black uppercase tracking-widest shadow-lg hover:bg-indigo-50 active:scale-95 transition-all"
            >
              Enviar a WhatsApp
            </button>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AccountingModule;
